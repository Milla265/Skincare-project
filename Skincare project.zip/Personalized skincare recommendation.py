#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Developing a Personalized recommender model for Skincare Products 


# In[2]:


# This project involves the development of a content-based recommendation model that should take the name of a 
# skincare product as input and return several similar products based on the product's ingredients and skin type




#This is my final year project for my Bachelors in science degree in Federal University Lokoja. 


#Imports


# In[3]:


import numpy as np
import pandas as pd
import re

from sklearn.decomposition import TruncatedSVD
from sklearn.manifold import TSNE

from bokeh.io import curdoc, push_notebook, output_notebook
from bokeh.layouts import column, layout
from bokeh.models import ColumnDataSource, Div, Select, Slider, TextInput, HoverTool
from bokeh.plotting import figure, show
from ipywidgets import interact, interactive, fixed, interact_manual


# In[4]:


# Loading data 


# In[5]:


data = pd.read_csv('cosmetics.csv')
data


# In[6]:


data.info()


# In[7]:


#There are no missing values and the ingredients column was previously thoroughly cleaned. 


# In[8]:


for i in range(len(data['Ingredients'])):
    data['Ingredients'].iloc[i] = str(data['Ingredients'].iloc[i]).replace('[', '').replace(']', '').replace("'", '').replace('"', '')


# In[9]:


all_Ingredients = []

for i in data['Ingredients']:
    Ingredients_list = i.split(', ')
    for j in Ingredients_list:
        all_Ingredients.append(j)


# In[10]:


all_Ingredients = sorted(set(all_Ingredients))
all_Ingredients[0:100]


# In[11]:


one_hot_list = [[0] * 0 for i in range(len(all_Ingredients))]

for i in data['Ingredients']:
    k=0
    for j in all_Ingredients:
        if j in i:
            one_hot_list[k].append(1)
        else:
            one_hot_list[k].append(0)
        k+=1
        
Ingredients_matrix = pd.DataFrame(one_hot_list).transpose()
Ingredients_matrix.columns = [sorted(set(all_Ingredients))]

Ingredients_matrix


# In[12]:


# This matrix contains zeros and ones -. 

# common ingredients were given lower weights. 
# Some ingredients that were very important for particular functions such as moisturising were given higher weights. 


# In[13]:


# Visualising similarities between products


# In[14]:


# For Dimensionality Reduction,TruncatedSVD and TSNE will be used to summarise the whole matrix in 2 values for each row. 
# This will help give a higher accuracy

# The x and y values can be plotted to visualise the similarities between the products.


# In[15]:


svd = TruncatedSVD(n_components=150, n_iter = 1000, random_state = 6)

# firstly reduce features to 150 with truncatedSVD - this suppresses some noise

svd_features = svd.fit_transform(Ingredients_matrix)
tsne = TSNE(n_components = 2, n_iter = 1000000, random_state = 6) 

# reduce 150 features to 2 using t-SNE with exact method

tsne_features = tsne.fit_transform(svd_features)

data['X'] = tsne_features[:, 0]
data['Y'] = tsne_features[:, 1]


# In[16]:


unique_types = ['Moisturizer', 'Cleanser', 'Treatment', 'Face Mask', 'Eye Cream',
       'Sun Protect']

source = ColumnDataSource(data)

plot = figure(title = "Mapped Similarities", width = 800, height = 600)
plot.xaxis.axis_label = "t-SNE 1"
plot.yaxis.axis_label = 't-SNE 2'

plot.circle(x = 'X', y = 'Y', source = source, fill_alpha=0.7, size=10,
           color = '#c0a5e3', alpha = 1)

plot.background_fill_color = "#E9E9E9"
plot.background_fill_alpha = 0.3

hover = HoverTool(tooltips=[('Name', '@Name'), ('Price', '@Price')])
plot.add_tools(hover)

def type_updater(Label = unique_types[0]):
    new_data = {'X' : data[data['Label'] == Label]['X'],
                'Y' : data[data['Label'] == Label]['Y'],
                'Label' : data[data['Label'] == Label]['Label'],
                'Label' : data[data['Label'] == Label]['Label']}
    source.data = new_data
    push_notebook()
  
output_notebook()
show(plot, notebook_handle = True)
interact(type_updater, Label = unique_types)


# In[ ]:





# In[ ]:





# In[17]:


# Creating the recommendation model 👩🏻‍💻

# The function below recommends products by:

# 🔍 taking the name of a product as input

# 🧴 only including products of the same type

# ➗ calculating cosine similarities and returning top 5 similar products


# In[ ]:





# In[33]:


def recommender(search):
    cs_list = []
    brand = []
    output = []
    binary_list = []
    idx = data[data['Name'] == search].index.item()
    for i in Ingredients_matrix.iloc[idx][1:]:
        binary_list.append(i)    
    point1 = np.array(binary_list).reshape(1, -1)
    point1 = [val for sublist in point1 for val in sublist]
    Label = data['Label'][data['Name'] == search].iat[0]
    Brand_search = data['Brand'][data['Name'] == search].iat[0]
    data_by_type = data[data['Label'] == Label]
    
    for j in range(data_by_type.index[0], data_by_type.index[0] + len(data_by_type)):
        binary_list2 = []
        for k in Ingredients_matrix.iloc[j][1:]:
            binary_list2.append(k)
        point2 = np.array(binary_list2).reshape(1, -1)
        point2 = [val for sublist in point2 for val in sublist]
        dot_product = np.dot(point1, point2)
        norm_1 = np.linalg.norm(point1)
        norm_2 = np.linalg.norm(point2)
        cos_sim = dot_product / (norm_1 * norm_2)
        cs_list.append(cos_sim)
    data_by_type = pd.DataFrame(data_by_type)
    data_by_type['cos_sim'] = cs_list
    data_by_type = data_by_type.sort_values('cos_sim', ascending=False)
    data_by_type = data_by_type[data_by_type.Name != search] 
    l = 0
    for m in range(len(data_by_type)):
        Brand = data_by_type['Brand'].iloc[l]
        if len(Brand) == 0:
            if Brand != Brand_search:
                Brand.append(Brand)
                output.append(data_by_type.iloc[l])
        elif Brand.count(Brand) < 2:
            if Brand!= Brand_search:
                output.append(data_by_type.iloc[l])
        l += 1
        
    return print('\033[1m', 'Recommending products similar to', search,':', '\033[0m'), print(pd.DataFrame(output)[['Name', 'cos_sim']].head(5))


# In[ ]:





# In[34]:


# Using function to get recommendations 📄

# we will input some product names into the function to see what recommendations we get!


# In[35]:


recommender("Crème de la Mer")


# In[ ]:





# In[36]:


recommender("Luna Sleeping Night Oil")


# In[ ]:





# In[39]:


recommender("The Water Cream")


# In[ ]:





# In[ ]:





# In[ ]:




